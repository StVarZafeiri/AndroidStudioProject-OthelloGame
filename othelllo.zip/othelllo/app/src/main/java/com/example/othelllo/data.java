
package com.example.othelllo;

public class data {
    public String name;
    public String value;

    public data(String name, String value) {
        this.name = name;
        this.value = value;
    }
}
