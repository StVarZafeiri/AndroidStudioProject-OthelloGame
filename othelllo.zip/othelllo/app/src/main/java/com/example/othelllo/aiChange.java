package com.example.othelllo;

public class aiChange {
    int [][] table;
    public aiChange(int[][] table) {
        this.table = table;
    }
    public void change(int i, int j, int ownColor, int otherColor) {
        /*id = "i"+ (char)(i + '0') + (char)(j + '0');
        int resID = getResources().getIdentifier(id, "id", getPackageName());
        ImageView img = findViewById(resID);

        String id1 = "i"+ (char)(i+1+'0')+ (char)(j+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img1 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i+1+'0')+ (char)(j+1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img2 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i+'0')+ (char)(j+1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img3 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i-1+'0')+ (char)(j+1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img4 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i-1+'0')+ (char)(j+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img5 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i-1+'0')+ (char)(j-1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img6 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i+'0')+ (char)(j-1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img7 = (ImageView) findViewById(resID);

        id1= "i"+ (char)(i+1+'0')+ (char)(j-1+'0');
        resID = getResources().getIdentifier(id1, "id", getPackageName());
        ImageView img8 = (ImageView) findViewById(resID);*/

        if (i + 1 < 8) {
            if (table[i + 1][j] != -1) {
                if (table[i + 1][j] == otherColor) {
                    for (int k = 1; k + i < 8; k++) {
                        if (table[i + k][j] != -1) {
                            if (table[i + k][j] == ownColor) {
                                if (ownColor == 1) {
                                    table[i + 1][j] = 1;
                                    for (k = 2; k + i < 8; k++) {
                                        if (table[i + k][j] != -1) {
                                            if (table[i + k][j] == otherColor) {
                                                table[i + k][j] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i + 1][j] = 2;
                                    for (k = 2; k + i < 8; k++) {
                                        if (table[i + k][j] != -1) {
                                            if (table[i + k][j] == otherColor) {
                                                table[i + k][j] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }

        if ((i + 1 < 8) && (j + 1 < 8)) {
            if (table[i + 1][j + 1] != -1) {
                if (table[i + 1][j + 1] == otherColor) {
                    for (int k = 1; (k + i < 8) && (k + j < 8); k++) {
                        if (table[i + k][j + k] != -1) {
                            if (table[i + k][j + k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i + 1][j + 1] = 1;
                                    for (k = 2; (k + i < 8) && (k + j < 8); k++) {
                                        if (table[i + k][j + k] != -1) {
                                            if (table[i + k][j + k] == otherColor) {
                                                table[i + k][j + k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i + 1][j + 1] = 2;
                                    for (k = 2; (k + i < 8) && (k + j < 8); k++) {
                                        if (table[i + k][j + k] != -1) {
                                            if (table[i + k][j + k] == otherColor) {
                                                table[i + k][j + k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }

        if (j + 1 < 8) {
            if (table[i][j + 1] != -1) {
                if (table[i][j + 1] == otherColor) {
                    for (int k = 1; k + j < 8; k++) {
                        if (table[i][j + k] != -1) {
                            if (table[i][j + k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i][j + 1] = 1;
                                    for (k = 2; k + j < 8; k++) {
                                        if (table[i][j + k] != -1) {
                                            if (table[i][j + k] == otherColor) {
                                                table[i][j + k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i][j + 1] = 2;
                                    for (k = 2; k + j < 8; k++) {
                                        if (table[i][j + k] != -1) {
                                            if (table[i][j + k] == otherColor) {
                                                table[i][j + k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }

        if ((i - 1 >= 0) && (j + 1 < 8)) {
            if (table[i - 1][j + 1] != -1) {
                if (table[i - 1][j + 1] == otherColor) {
                    for (int k = 1; (i - k >= 0) && (k + j < 8); k++) {
                        if (table[i - k][j + k] != -1) {
                            if (table[i - k][j + k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i - 1][j + 1] = 1;
                                    for (k = 2; (i - k >= 0) && (k + j < 8); k++) {
                                        if (table[i - k][j + k] != -1) {
                                            if (table[i - k][j + k] == otherColor) {
                                                table[i - k][j + k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i - 1][j + 1] = 2;
                                    for (k = 2; (i - k >= 0) && (k + j < 8); k++) {
                                        if (table[i - k][j + k] != -1) {
                                            if (table[i - k][j + k] == otherColor) {
                                                table[i - k][j + k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        if (i - 1 >= 0) {
            if (table[i - 1][j] != -1) {
                if (table[i - 1][j] == otherColor) {
                    for (int k = 1; i - k >= 0; k++) {
                        if (table[i - k][j] != -1) {
                            if (table[i - k][j] == ownColor) {
                                if (ownColor == 1) {
                                    table[i - 1][j] = 1;
                                    for (k = 2; i - k >= 0; k++) {
                                        if (table[i - k][j] != -1) {
                                            if (table[i - k][j] == otherColor) {
                                                table[i - k][j] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i - 1][j] = 2;
                                    for (k = 2; i - k >= 0; k++) {
                                        if (table[i - k][j] != -1) {
                                            if (table[i - k][j] == otherColor) {
                                                table[i - k][j] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        if ((i - 1 >= 0) && (j - 1 >= 0)) {
            if (table[i - 1][j - 1] != -1) {
                if (table[i - 1][j - 1] == otherColor) {
                    for (int k = 1; (i - k >= 0) && (j - k >= 0); k++) {
                        if (table[i - k][j - k] != -1) {
                            if (table[i - k][j - k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i - 1][j - 1] = 1;
                                    for (k = 2; (i - k >= 0) && (j - k >= 0); k++) {
                                        if (table[i - k][j - k] != -1) {
                                            if (table[i - k][j - k] == otherColor) {
                                                table[i - k][j - k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i - 1][j - 1] = 2;
                                    for (k = 2; (i - k >= 0) && (j - k >= 0); k++) {
                                        if (table[i - k][j - k] != -1) {
                                            if (table[i - k][j - k] == otherColor) {
                                                table[i - k][j - k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }

        if (j - 1 >= 0) {
            if (table[i][j - 1] != -1) {
                if (table[i][j - 1] == otherColor) {
                    for (int k = 1; j - k >= 0; k++) {
                        if (table[i][j - k] != -1) {
                            if (table[i][j - k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i][j - 1] = 1;
                                    for (k = 2; j - k >= 0; k++) {
                                        if (table[i][j - k] != -1) {
                                            if (table[i][j - k] == otherColor) {
                                                table[i][j - k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i][j - 1] = 2;
                                    for (k = 2; j - k >= 0; k++) {
                                        if (table[i][j - k] != -1) {
                                            if (table[i][j - k] == otherColor) {
                                                table[i][j - k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        if ((i + 1 < 8) && (j - 1 >= 0)) {
            if (table[i + 1][j - 1] != -1) {
                if (table[i + 1][j - 1] == otherColor) {
                    for (int k = 1; (i + k < 8) && (j - k >= 0); k++) {
                        if (table[i + k][j - k] != -1) {
                            if (table[i + k][j - k] == ownColor) {
                                if (ownColor == 1) {
                                    table[i + 1][j - 1] = 1;
                                    for (k = 2; (i + k < 8) && (j - k >= 0); k++) {
                                        if (table[i + k][j - k] != -1) {
                                            if (table[i + k][j - k] == otherColor) {
                                                table[i + k][j - k] = 1;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                } else {
                                    table[i + 1][j - 1] = 2;
                                    for (k = 2; (i + k < 8) && (j - k >= 0); k++) {
                                        if (table[i + k][j - k] != -1) {
                                            if (table[i + k][j - k] == otherColor) {
                                                table[i + k][j - k] = 2;
                                            } else {
                                                break;
                                            }
                                        } else {
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }
        }
    }
    public int value(boolean isBlack) {
        int value = 0;
        //if(isBlack) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (table[i][j] == 1) {
                        value++;
                    } else if (table[i][j] == 2) {
                        value--;
                    }
                }
            }
        /*}
        else {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (table[i][j] == 1) {
                        value++;
                    } else if (table[i][j] == 2) {
                        value--;
                    }
                }
            }
        }*/
        return value;
    }
}
