package com.example.othelllo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    //public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /** Called when the user taps the Send button */
    public void singleplayer(View view) {
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        startActivity(intent);

    }
    public void multiplayer(View view) {
        Intent intent = new Intent(this, MultiPlayer.class);
        startActivity(intent);

    }

}