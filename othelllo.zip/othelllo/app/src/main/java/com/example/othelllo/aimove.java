package com.example.othelllo;

public class aimove {
    public int row, column, value;

    public aimove(int row, int column) {
        this.row = row;
        this.column = column;
        this.value = 0;
    }
}
