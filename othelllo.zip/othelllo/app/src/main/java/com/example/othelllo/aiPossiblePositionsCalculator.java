package com.example.othelllo;

public class aiPossiblePositionsCalculator {
    public aiPossiblePositionsCalculator() {

    }

    public void remove(int [][] table) {
        for(int i=0; i<8; i++ ) {
            for (int j = 0; j < 8; j++) {
                //String id = "i" + (char) (i + '0') + (char) (j + '0');
                //int resID = getResources().getIdentifier(id, "id", getPackageName());
                //ImageView img = findViewById(resID);
                //if (img.getDrawable() != null) {
                    //String imageName2 = (String) img.getContentDescription();
                    if(table[i][j] == 0) {
                        //image.setImageResource(R.drawable.ic_black);
                        table[i][j] = -1;
                    }
                }
            }
        }

    public void calculate(int [][] table, int ownColor, int otherColor) {
        for(int i=0; i<8; i++ ) {
            for (int j = 0; j < 8; j++) {
                if(table[i][j] == -1) {
                /*String id = "i" + (char) (i + '0') + (char) (j + '0');
                int resID = getResources().getIdentifier(id, "id", getPackageName());
                ImageView img = findViewById(resID);*/
                    //if (img.getDrawable() == null) {
                    /*String id1 = "i" + (char) (i + 1 + '0') + (char) (j + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img1 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i + 1 + '0') + (char) (j + 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img2 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i + '0') + (char) (j + 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img3 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i - 1 + '0') + (char) (j + 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img4 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i - 1 + '0') + (char) (j + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img5 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i - 1 + '0') + (char) (j - 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img6 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i + '0') + (char) (j - 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img7 = (ImageView) findViewById(resID);

                    id1 = "i" + (char) (i + 1 + '0') + (char) (j - 1 + '0');
                    resID = getResources().getIdentifier(id1, "id", getPackageName());
                    ImageView img8 = (ImageView) findViewById(resID);*/

                    //if (img1 != null && img1.getDrawable() != null) {
                    //String imageName = (String) img1.getContentDescription();
                    if (i + 1 < 8 && table[i + 1][j] != -1) {
                        if (table[i + 1][j] == otherColor) {
                            for (int k = 1; k + i < 8; k++) {
                                if (table[i + k][j] != -1) {
                                    if (table[i + k][j] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    if (i + 1 < 8 && j + 1 < 8 && table[i + 1][j + 1] != -1) {
                        if (table[i + 1][j + 1] == otherColor) {
                            for (int k = 1; k + i < 8 && k + j < 8; k++) {
                                if (table[i + k][j + k] != -1) {
                                    if (table[i + k][j + k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    if (j + 1 < 8 && table[i][j + 1] != -1) {
                        if (table[i][j + 1] == otherColor) {
                            for (int k = 1; k + j < 8; k++) {
                                if (table[i][j + k] != -1) {
                                    if (table[i][j + k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    if (i - 1 >= 0 && j + 1 < 8 && table[i - 1][j + 1] != -1) {
                        if (table[i - 1][j + 1] == otherColor) {
                            for (int k = 1; k + j < 8 && i - k >= 0; k++) {
                                if (table[i - k][j + k] != -1) {
                                    if (table[i - k][j + k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                    if (i - 1 >= 0 && table[i - 1][j] != -1) {
                        if (table[i - 1][j] == otherColor) {
                            for (int k = 1; i - k >= 0; k++) {
                                if (table[i - k][j] != -1) {
                                    if (table[i - k][j] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                    if (i - 1 >= 0 && j - 1 >= 0 && table[i - 1][j - 1] != -1) {
                        if (table[i - 1][j - 1] == otherColor) {
                            for (int k = 1; i - k >= 0 && j - k >= 0; k++) {
                                if (table[i - k][j - k] != -1) {
                                    if (table[i - k][j - k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                    if (j - 1 >= 0 && table[i][j - 1] != -1) {
                        if (table[i][j - 1] == otherColor) {
                            for (int k = 1; j - k >= 0; k++) {
                                if (table[i][j - k] != -1) {
                                    if (table[i][j - k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }

                    if (i + 1 < 8 && j - 1 >= 0 && table[i + 1][j - 1] != -1) {
                        if (table[i + 1][j - 1] == otherColor) {
                            for (int k = 1; k + i < 8 && j - k >= 0; k++) {
                                if (table[i + k][j - k] != -1) {
                                    if (table[i + k][j - k] == ownColor) {
                                        table[i][j] = 0;
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
